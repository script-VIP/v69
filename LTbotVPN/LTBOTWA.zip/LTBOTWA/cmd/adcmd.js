const fs = require('fs');
const path = require('path');

module.exports = async ({ isAdmin, isOwner, msg, lunaticreply }) => {
    if (!isAdmin && !isOwner) return lunaticreply("❌ Khusus owner bot!");
  try {
    const text = msg.message?.extendedTextMessage?.text || msg.message?.conversation || msg.text || '';
    const lines = text.split('\n').map(line => line.trim()).filter(Boolean);

    if (lines.length < 3) {
      return lunaticreply('⚠️ Format salah!\nContoh:\nadcmd\nnamafile.js\nkode fitur...');
    }

    const filename = lines[1];
    const code = lines.slice(2).join('\n');

    if (!filename.endsWith('.js')) {
      return lunaticreply('❌ Nama file harus diakhiri `.js`');
    }

    const filePath = path.join(__dirname, filename);
    fs.writeFileSync(filePath, code);
    lunaticreply(`✅ Fitur *${filename}* berhasil ditambahkan!\nLetak: \`cmd/${filename}\``);
  } catch (e) {
    console.error('❌ Error adcmd:', e);
    lunaticreply('❌ Terjadi error saat menjalankan perintah.');
  }
};
