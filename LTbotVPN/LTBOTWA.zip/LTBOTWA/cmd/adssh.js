const fs = require('fs');
const { Client } = require('ssh2');

module.exports = async ({ isAdmin, isOwner, args, lunaticreply }) => {
    if (!isAdmin && !isOwner) return lunaticreply("❌ ```KHUSUS OWNER``` ");

  // Ambil prefix dari prefix.json
  let prefix = '!';
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    prefix = pf.prefix || '!';
  } catch {}

  // batas ambil Prefix
  const [namaakun, passakun, limitIP, expired, targetVps] = args;
  if (!namaakun || !passakun || !limitIP || !expired || !targetVps) {
    return lunaticreply(
      `❗ *Format Salah!*\n\n*Contoh:*\n${prefix}adssh nama password limitIP expired namaVPS\n\n*Example:*\n${prefix}adssh dian dian123 1 1 ram9`
    );
  }

  const vpsPath = './avars/vpsdata.json';
  if (!fs.existsSync(vpsPath)) return lunaticreply('❌ ```DATA VPS KOSONG```');

  const vpsData = JSON.parse(fs.readFileSync(vpsPath));
  const target = vpsData[targetVps];
  if (!target) {
    return lunaticreply(`❌ VPS "${targetVps}" tidak ditemukan!\nGunakan: *${prefix}listvps*`);
  }

  const conn = new Client();
  conn.on('ready', () => {
    // PERBAIKAN PATH DI SINI:
    // Coba beberapa kemungkinan path
    const possiblePaths = [
      '/root/LTBOTWA/LTBOTVPN/buatSSH',
      '/home/LTBOTWA/LTBOTVPN/buatSSH', 
      '/usr/local/bin/LTBOTVPN/buatSSH',
      '/usr/bin/LTBOTVPN/buatSSH',
      '/opt/LTBOTWA/LTBOTVPN/buatSSH'
    ];

    const tryExecute = (index = 0) => {
      if (index >= possiblePaths.length) {
        return lunaticreply('❌ File buatSSH tidak ditemukan di semua lokasi!');
      }

      const currentPath = possiblePaths[index];
      const checkCmd = `[ -f "${currentPath}" ] && echo "exists" || echo "not exists"`;
      
      conn.exec(checkCmd, (err, stream) => {
        if (err) {
          // Coba path berikutnya
          return tryExecute(index + 1);
        }

        let output = '';
        stream.on('data', (data) => output += data.toString());
        stream.on('close', () => {
          if (output.includes('exists')) {
            // File ditemukan, jalankan command
            const cmd = `bash ${currentPath} ${namaakun} ${passakun} ${limitIP} ${expired}`;
            conn.exec(cmd, (err, stream) => {
              if (err) return lunaticreply('❌ Gagal eksekusi command di VPS');

              let result = '';
              stream.on('data', chunk => result += chunk.toString());
              stream.stderr.on('data', errChunk => result += errChunk.toString());
              stream.on('close', () => {
                conn.end();
                if (!result.trim()) {
                  return lunaticreply('⚠️ Tidak ada output. Cek manual di VPS.');
                }

                const beautify = '```' + result.trim() + '```';
                lunaticreply(`✅ *SSH Berhasil dibuat:*\n\n${beautify}`);
              });
            });
          } else {
            // File tidak ditemukan, coba path berikutnya
            tryExecute(index + 1);
          }
        });
      });
    };

    // Mulai pencarian file
    tryExecute();

  }).on('error', err => {
    lunaticreply(`❌ Gagal konek ke VPS: ${err.message}`);
  }).connect({
    host: target.ip,
    port: 22,
    username: 'root',
    password: target.pass
  });
};