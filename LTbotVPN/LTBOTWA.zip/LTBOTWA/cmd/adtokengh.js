const fs = require('fs');
const path = require('path');

module.exports = async ({ q, lunaticreply, isAdmin, isOwner }) => {
  // 🔒 Hanya admin atau owner
  if (!isAdmin && !isOwner) {
    return lunaticreply('❌ Fitur ini hanya bisa digunakan oleh Admin atau Owner.');
  }

  if (!q) {
    return lunaticreply(`❌ Masukkan token GitHub!\n\nContoh:\nadtokengh ghp_xxx`);
  }

  const token = q.trim();

  const savePath = path.join(__dirname, '../avars/tokengh.json');

  try {
    fs.writeFileSync(savePath, JSON.stringify({ token }, null, 2));
    lunaticreply('✅ Token GitHub berhasil disimpan ke `avars/tokengh.json`');
  } catch (err) {
    console.error('[ADDTOKEN ERROR]', err.message);
    lunaticreply('❌ Gagal menyimpan token.');
  }
};