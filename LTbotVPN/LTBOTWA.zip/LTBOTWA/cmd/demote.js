module.exports = async ({ lunatix, msg, sender, isGroup, isAdmin, lunaticreply, args }) => {
    if (!isGroup) return lunaticreply('❌ Perintah ini hanya bisa digunakan di dalam grup.');

    if (!isAdmin) return lunaticreply('⚠️ Hanya *admin grup* yang bisa menjalankan perintah ini.');

    const groupId = msg.key.remoteJid
    const groupMetadata = await lunatix.groupMetadata(groupId)
    const participants = groupMetadata.participants

    let target

    // Dari reply
    if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
        target = msg.message.extendedTextMessage.contextInfo.participant
    }
    // Dari mention
    else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0]
    }
    // Dari argumen nomor
    else if (args[0]) {
        const nomor = args[0].replace(/[^0-9]/g, '')
        target = nomor + '@s.whatsapp.net'
    } else {
        return lunaticreply('⚠️ Tag, balas pesan, atau ketik nomor yang ingin *didemote*. Contoh:\n!demote 628xxx')
    }

    // Cek apakah user ada di grup
    const isMember = participants.some(p => p.id === target)
    if (!isMember) return lunaticreply('❌ User tidak ditemukan di grup.')

    // Cek apakah target adalah admin
    const targetData = participants.find(p => p.id === target)
    const isTargetAdmin = targetData?.admin !== undefined
    if (!isTargetAdmin) return lunaticreply('⚠️ User tersebut bukan admin.')

    try {
        await lunatix.groupParticipantsUpdate(groupId, [target], 'demote')
        lunaticreply('✅ User berhasil *diturunkan* dari admin.')
    } catch (err) {
        console.error('❌ Error saat demote:', err)
        lunaticreply('❌ Gagal demote. Pastikan bot adalah *admin grup*!')
    }
}
