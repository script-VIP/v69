module.exports = async ({ isAdmin,  lunatix, msg, lunaticreply }) => {
  const caption = `
━━━━━━━━━━━━━━━━━  
*JOIN GROUP*
━━━━━━━━━━━━━━━━━
whatsapp.com/channel/0029Vb5jolhDzgTIeKlSDc1z
☻︎ Testimoni Pembelian : https://t.me/Aivpn3
1 chat.whatsapp.com/E8IrnV8lr1qK2oib0Og0ks
2 chat.whatsapp.com/FlMrIejIIRTJcpHTIE84td
3 chat.whatsapp.com/LQOX9j0fl7KElaqffvI22f
4 chat.whatsapp.com/Eqvjh8srrjiCvXSnQhUHIX
5 chat.whatsapp.com/GqzzxF3i10zHcSIiyeEqk7
6 chat.whatsapp.com/JI49oMiZWl3GFIjixyDIgR
━━━━━━━━━━━━━━━━━
  `.trim();

  await lunatix.sendMessage(msg.key.remoteJid, {
    text: caption,
  }, { quoted: msg });
};
