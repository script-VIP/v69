module.exports = async ({ lunatix, isOwner, lunaticreply }) => {
if (!isOwner) return lunaticreply("❌ ```KHUSUS LT KANG BASH JS PYTHON🗿``` ");
const teksPromosi = `
‎━━━━━━━━━━━━━━━
‎         *NgoprekVPN*
‎━━━━━━━━━━━━━━━
‎Config Premium:
‎Ssh/openvpn/udp
‎Vmes/vless/trojan
‎▬▬▬▬▬▬▬▬▬▬▬
‎*SERVER SINGAPURA*
‎▬▬▬▬▬▬▬▬▬▬▬
‎🇸🇬 : digital Ocean
‎> 1 bulan / 1 IP : 5k
‎> 1 bulan / 2 IP : 7k
‎> 2 bulan / 3 IP : 10k
‎> 2 bulan / 4 IP : 12k
‎> 3 bulan / 4 IP : 15k
‎> 3 bulan / 5 IP : 25k
‎━━━━━━━━━━━━━━━
‎- garansi 100%
‎- Bisa trial dulu
‎- cocok order
‎- ga cocok jangan order
‎▬▬▬▬▬▬▬▬▬▬▬
‎    *VPS TUNNELING*
‎▬▬▬▬▬▬▬▬▬▬▬
‎Ram 1gb/bw 1 TB : 20k
‎Ram 2gb/bw 2 TB : 30k
‎Ram 2gb/bw 3 TB : 35k
‎Ram 4gb/bw 4 TB : 50k
‎Ram 8gb/bw 5 TB : 70k
‎Ram 16gb/bw 8TB: 100k
‎━━━━━━━━━━━━━━━
‎- Siap Pakai,jualan
‎- garansi 30 hari
‎- sudah install Sripts
‎- SC full fitur
‎- support wildcards
‎▬▬▬▬▬▬▬▬▬▬▬
‎  *SCRIPT TUNNELING*
‎▬▬▬▬▬▬▬▬▬▬▬
‎Sewa AutoScript :
‎1 bulan :   6k : 1 IP
‎1 bulan : 10k : 2 IP
‎2 bulan : 15k : 3 IP
‎1 Tahun: 150k : Unli IP
‎▬▬▬▬▬▬▬▬▬▬▬
‎Script OpenSource : 200k
‎OpenSource? ( script -
‎Jadi Hak milik selamanya )
‎Ke untungan Opensource?
‎━━━━━━━━━━━━━━━
‎- script jadi milik anda
‎- script bisa di sewakan
‎- script bisa d jual lagi
‎- script bebas Custom
‎- script ringan , full fitur
‎━━━━━━━━━━━━━━━
*‎Grup NgoprekVPN 3:*
‎https://chat.whatsapp.com/C7TZ8vsaRRDFldMeYhx5yq?mode=ac_t
*Config Premium Murah (5k)*
https://chat.whatsapp.com/IrzXvqpAGVPHymuvVLzqpO?mode=ac_t
*Testi. NgoprekVPN*
https://whatsapp.com/channel/0029Vb6N9mi3wtazxwWJEQ2G
‎‎`;
try {
const groups = await lunatix.groupFetchAllParticipating();
let sukses = 0, gagal = 0;
for (const id in groups) {
try {
await lunatix.sendMessage(id, { text: teksPromosi });
await new Promise(res => setTimeout(res, 1500)); // delay biar anti banned/spam
sukses++
} catch (e) {
gagal++
}
}
lunaticreply(`✅ Promosi dikirim ke ${sukses} grup.\n❌ Gagal kirim ke ${gagal} grup.`);
} catch (err) {
console.error("❌ Error broadcast promosi:", err);
lunaticreply("❌ Gagal mengirim promosi.");
}
};