module.exports = async ({ lunatix, isOwner, lunaticreply }) => {
if (!isOwner) return lunaticreply("❌ ```KHUSUS ADMIN🗿``` ");
const teksPromosi = `
‎*PRODUK JUALAN ADMIN 08981874211* 
━━━━━━━━━━━━━━━━━━
*🫟 KUOTA UNLIMITED VIDIO ®30.000*
*🫟 KUOTA VIDIO + KONFIG ®38.000*
*🫟 MASA AKTIF XL 1 TAHUN ®5.000*
🫟 *VPS RAM 4 ®55.000*
🫟 *VPS RAM 8 ®75.000*
🫟 *KONFIG PREMIUM SERVER SG / INDO*
* *®8.000/BULAN 1HP*
* *®10.000/BULAN 2HP*
> XL VIDEO all tkp
> XL EDUKASI all tkp
> AXIS EDUKASI  all tkp
> IM3 APPS FUN alltkp
> TSEL ILMUPEDIA jatim Jateng riau
> Bisa Request konfig yg lainya
━━━━━━━━━━━━━━━━━━
* Untuk lebih lengkap Produk, harga, dan spesifikasi nya . Klik : wa.me/c/628981874211
* Testimoni pembelian : t.me/aivpn3
* *ORDER HUB : wa.me/628981874211*
*`MY GRUP`*
whatsapp.com/channel/0029Vb5jolhDzgTIeKlSDc1z
1 chat.whatsapp.com/E8IrnV8lr1qK2oib0Og0ks
2 chat.whatsapp.com/FlMrIejIIRTJcpHTIE84td
3 chat.whatsapp.com/LQOX9j0fl7KElaqffvI22f
4 chat.whatsapp.com/Eqvjh8srrjiCvXSnQhUHIX
5 chat.whatsapp.com/GqzzxF3i10zHcSIiyeEqk7
6 chat.whatsapp.com/JI49oMiZWl3GFIjixyDIgR
‎‎`;
try {
const groups = await lunatix.groupFetchAllParticipating();
let sukses = 0, gagal = 0;
for (const id in groups) {
try {
await lunatix.sendMessage(id, { text: teksPromosi });
await new Promise(res => setTimeout(res, 1500)); // delay biar anti banned/spam
sukses++
} catch (e) {
gagal++
}
}
lunaticreply(`✅ Promosi dikirim ke ${sukses} grup.\n❌ Gagal kirim ke ${gagal} grup.`);
} catch (err) {
console.error("❌ Error broadcast promosi:", err);
lunaticreply("❌ Gagal mengirim promosi.");
}
};