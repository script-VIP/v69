const fs = require('fs');
const path = require('path');

module.exports = async ({ lunaticreply }) => {
  const filePath = path.join(__dirname, '../avars/prefix.json');

  let prefix = '!';
  try {
    const data = fs.readFileSync(filePath, 'utf-8');
    const json = JSON.parse(data);
    prefix = json.prefix || '!';
  } catch (err) {
    // Tetap lanjut pakai default
  }

  lunaticreply(`📍 Prefix yang sedang aktif adalah: *${prefix}*`);
};