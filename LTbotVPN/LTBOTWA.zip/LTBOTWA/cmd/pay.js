// cmd/payment.js

module.exports = async ({ lunaticreply }) => {
  const teks = `
*💳 PAYMENT INFO*
Harga : wa.me/c/628981874211
*`Metode Pembayaran :`*
* *Scan Qris* wa.me/p/9833749623323521/628981874211
* *Dana*       08981874211
* *Gopay*     08981874211
* *Shopeepay*  08981874211
* *Seabank*    901364925581
> _Screenshot Bukti Transfer_
`.trim();

  lunaticreply(teks);
};
