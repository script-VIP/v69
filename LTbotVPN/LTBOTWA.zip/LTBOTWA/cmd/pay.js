// cmd/payment.js

module.exports = async ({ lunaticreply }) => {
  const teks = `
*💳 PAYMENT INFO*
========================
 *Nama* : DIAN
========================
 *DANA*     : 083197765857
 *BCA*      : 2782129857
 *SeaBANK*  : 901711609062
========================

*BUKTI TF KIRIM.*
`.trim();

  lunaticreply(teks);
};
