module.exports = async ({ lunatix, msg, sender, isGroup, isAdmin, lunaticreply, args }) => {
    if (!isGroup) return lunaticreply('❌ Perintah ini hanya bisa digunakan di dalam grup.');
    if (!isAdmin) return lunaticreply('⚠️ Perintah ini hanya untuk admin grup.');

    const groupId = msg.key.remoteJid; // ✅ ID grup yang benar
    const groupMetadata = await lunatix.groupMetadata(groupId);
    const participants = groupMetadata.participants;

    let target;

    // Dari reply
    if (msg.message.extendedTextMessage?.contextInfo?.participant) {
        target = msg.message.extendedTextMessage.contextInfo.participant;
    }
    // Dari mention
    else if (msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // Dari nomor manual
    else if (args[0]) {
        const nomor = args[0].replace(/[^0-9]/g, '');
        target = `${nomor}@s.whatsapp.net`;
    } else {
        return lunaticreply('⚠️ Tag, balas pesan, atau ketik nomor user yang ingin dipromosikan.');
    }

    // Cek apakah user ada di grup
    const isMember = participants.some(p => p.id === target);
    if (!isMember) return lunaticreply('❌ User tidak ditemukan dalam grup.');

    // Promote
    try {
        await lunatix.groupParticipantsUpdate(groupId, [target], 'promote');
        lunaticreply('✅ User telah dipromosikan menjadi admin grup.');
    } catch (err) {
        console.error(err);
        lunaticreply('❌ Gagal promote. Pastikan bot adalah admin grup!');
    }
};
