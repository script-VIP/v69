const fs = require('fs');
const axios = require('axios');
module.exports = async ({ q, lunaticreply, isAdmin, isOwner }) => {
if (!isAdmin && !isOwner) {
return lunaticreply(' ```husus Admin dan Owner``` ');
}
if (!q) {
return lunaticreply(`❌ Format: reip username exp\n\nContoh:\nreip lunatic 90`);
}
const args = q.trim().split(/\s+/);
if (args.length < 2) {
return lunaticreply(`❌ Format: reip username exp\n\nContoh:\nreip lunatic 90`);
}
const [namaInput, hariStr] = args;
const nama = namaInput.toLowerCase();
const hari = parseInt(hariStr);
if (isNaN(hari) || hari < 1) {
return lunaticreply(`❌ Expired harus angka (hari)`);
}
// Hitung tanggal expired baru
const now = new Date();
now.setDate(now.getDate() + hari);
const newDate = now.toISOString().split('T')[0];
// 🔐 Ambil token
let token;
try {
const tk = JSON.parse(fs.readFileSync('./avars/tokengh.json'));
token = tk.token;
} catch {
return lunaticreply(`❌ Gagal membaca token GitHub di avars/tokengh.json`);
}
if (!token) {
return lunaticreply(`❌ Token GitHub belum diset!`);
}
const owner = 'ianexec';
const repo = 'permission';
const path = 'regist';
const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
try {
const { data } = await axios.get(apiUrl, {
headers: {
Authorization: `Bearer ${token}`,
Accept: 'application/vnd.github.v3+json',
},
});
const content = Buffer.from(data.content, 'base64').toString();
const lines = content.split('\n');
let updated = false;
const updatedLines = lines.map(line => {
if (!line.startsWith('###')) return line;
const parts = line.replace('###', '').trim().split(/\s+/);
const [user, oldDate, ip] = parts;
if (user.toLowerCase() === nama) {
updated = true;
return `### ${user} ${newDate} ${ip}`;
}
return line;
});
if (!updated) {
return lunaticreply(`⚠️ Tidak ditemukan username *${nama}* di file regist.`);
}
const newEncoded = Buffer.from(updatedLines.join('\n')).toString('base64');
await axios.put(apiUrl, {
message: `renewregist: perpanjang ${nama}`,
content: newEncoded,
sha: data.sha,
}, {
headers: {
Authorization: `Bearer ${token}`,
Accept: 'application/vnd.github.v3+json',
},
});
lunaticreply(`✅ Masa aktif *${nama}* berhasil diperbarui menjadi *${hari} hari* (expired: ${newDate})`);
} catch (err) {
console.error('[RENEWREGIST ERROR]', err.response?.data || err.message);
lunaticreply(`❌ Gagal melakukan pembaruan ke GitHub.`);
}
};