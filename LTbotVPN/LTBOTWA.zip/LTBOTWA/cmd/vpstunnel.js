const fs = require('fs');
const path = './avars/vpsdata.json';

module.exports = async ctx => {
  const { lunaticreply, args, isAdmin } = ctx;
  if (!isAdmin) return lunaticreply('Khusus admin! 🗿');

  const [ip, password] = args;
  if (!ip || !password)
    return lunaticreply('❗ Format: !advpsdata <ip> <password>\nContoh: !advpsdata 1.2.3.4 pass123');

  // Data default VPS
  const data = {
    ip,
    password,
    username: 'root',
    port: 22
  };

  try {
    // Simpan ke file
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
    lunaticreply(`✅ Data VPS berhasil disimpan!\nIP      : ${ip}\nUsername: root\nPassword: ${password}`);
  } catch (err) {
    console.error('❌ Gagal menyimpan vpsData:', err);
    lunaticreply('❌ Gagal menyimpan data VPS!');
  }
};
